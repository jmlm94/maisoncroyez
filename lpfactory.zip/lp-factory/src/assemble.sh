#!/bin/bash
set -e
A=assets
OUT=maison-croyez-landing.html
{
  echo '<title>Maison Croyez — Attract What You Sense</title>'
  echo '<meta name="viewport" content="width=device-width, initial-scale=1">'
  echo '<style>'
  cat fonts.css
  cat styles.css
  echo '</style>'
  echo '<div id="root"></div>'
  echo '<script>'
  cat $A/react-18.3.1/package/umd/react.production.min.js
  echo ''
  cat $A/react-dom-18.3.1/package/umd/react-dom.production.min.js
  echo ''
  cat $A/htm-3.1.1/package/dist/htm.js
  echo ''
  echo '</script>'
  echo '<script>'
  cat images.js
  echo '</script>'
  echo '<script>'
  cat app.js
  echo '</script>'
} > $OUT
wc -c $OUT
